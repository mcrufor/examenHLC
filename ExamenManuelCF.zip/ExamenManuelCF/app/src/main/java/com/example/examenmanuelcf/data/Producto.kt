package com.example.examenmanuelcf.data

data class Producto (val nombre: String, val precio: Int)